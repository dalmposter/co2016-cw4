I declared some other classes within Example3D to make it easier to run it.
Included is a batch (run.bat) and shell (run.sh) script which will compile and run my coursework submission on windows/linux respectively.
Note that these scripts require java and javac to be setup as commands (generally done when java is installed)
Alternatively you can use a terminal to manually compile and run it,
note this would require using arguments to use the libraries or have the environment setup to use these libraries.