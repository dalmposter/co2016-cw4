#!/usr/bin/env bash
javac -cp lib/j3dcore.jar:lib/j3dutils.jar:lib/vecmath.jar:lib/jogamp-fat.jar Example3D.java
java -cp lib/j3dcore.jar:lib/j3dutils.jar:lib/vecmath.jar:lib/jogamp-fat.jar:. Example3D