I declared some other classes within Example3D to make it easier to run it.
Included is a batch (run.bat) and shell (run.sh) script which will compile and run my coursework submission on windows/linux respectively.
Note that these scripts require java and javac to be setup as commands (generally done when java is installed)
Alternatively you can use a terminal to manually compile and run it,
note this would require using arguments to use the libraries or have the environment setup to use these libraries.

For the best viewing angles I suggest (from the initial position) zooming in and out, and simple left/right movement.
In addition you can get a nice view by rotating the system such that you are looking down on the planets orbits.
The collision events surrounding rocket1 toggle quite a potent ambient light so one can see the lighting/shadows in effect better (when ambient light is off)
Or one can see the materials and textures a bit better (when the ambient light is on)